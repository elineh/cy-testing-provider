module DidYouMean
  VERSION = "1.6.3".freeze
end

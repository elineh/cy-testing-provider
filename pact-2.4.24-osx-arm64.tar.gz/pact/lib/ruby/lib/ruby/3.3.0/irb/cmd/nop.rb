# frozen_string_literal: true

# This file is just a placeholder for backward-compatibility.
# Please require 'irb' and inherit your command from `IRB::Command::Base` instead.

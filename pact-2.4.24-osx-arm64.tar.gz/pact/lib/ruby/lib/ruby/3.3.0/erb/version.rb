# frozen_string_literal: true
class ERB
  VERSION = '4.0.3'
  private_constant :VERSION
end

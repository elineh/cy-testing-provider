# frozen_string_literal: true

module SyntaxSuggest
  VERSION = "2.0.0"
end
